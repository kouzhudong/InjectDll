#include <ntifs.h>
#include <windef.h>
#include <ntddk.h>
#include <ntstrsafe.h>

#include <Aux_klib.h> //source����Ҫ��TARGETLIBS=$(DDK_LIB_PATH)\Aux_klib.lib

//TARGETLIBS=$(DDK_LIB_PATH)\ksecdd.lib 

#define TAG  'tset' //test

typedef
VOID
(*PKNORMAL_ROUTINE) (
    IN PVOID NormalContext,
    IN PVOID SystemArgument1,
    IN PVOID SystemArgument2
    );

typedef
VOID
(*PKKERNEL_ROUTINE) (
    IN struct _KAPC *Apc,
    IN OUT PKNORMAL_ROUTINE *NormalRoutine,
    IN OUT PVOID *NormalContext,
    IN OUT PVOID *SystemArgument1,
    IN OUT PVOID *SystemArgument2
    );

typedef
VOID
(*PKRUNDOWN_ROUTINE) (
    IN struct _KAPC *Apc
    );

typedef enum _KAPC_ENVIRONMENT {
    OriginalApcEnvironment,
    AttachedApcEnvironment,
    CurrentApcEnvironment,
    InsertApcEnvironment
} KAPC_ENVIRONMENT;

NTKERNELAPI
VOID
KeInitializeApc (
    __out PRKAPC Apc,
    __in PRKTHREAD Thread,
    __in KAPC_ENVIRONMENT Environment,
    __in PKKERNEL_ROUTINE KernelRoutine,
    __in_opt PKRUNDOWN_ROUTINE RundownRoutine,
    __in_opt PKNORMAL_ROUTINE NormalRoutine,
    __in_opt KPROCESSOR_MODE ProcessorMode,
    __in_opt PVOID NormalContext
    );

PLIST_ENTRY
KeFlushQueueApc (
    __inout PKTHREAD Thread,
    __in KPROCESSOR_MODE ProcessorMode
    );

NTKERNELAPI
BOOLEAN
KeInsertQueueApc (
    __inout PRKAPC Apc,
    __in_opt PVOID SystemArgument1,
    __in_opt PVOID SystemArgument2,
    __in KPRIORITY Increment
    );

BOOLEAN
KeRemoveQueueApc (
    __inout PKAPC Apc
    );

//////////////////////////////////////////////////////////////////////////////////////////////////

//VOID
//PspQueueApcSpecialApc(
//    IN PKAPC Apc,
//    IN PKNORMAL_ROUTINE *NormalRoutine,
//    IN PVOID *NormalContext,
//    IN PVOID *SystemArgument1,
//    IN PVOID *SystemArgument2
//    )
//{
//    PAGED_CODE();
//
//    UNREFERENCED_PARAMETER (NormalRoutine);
//    UNREFERENCED_PARAMETER (NormalContext);
//    UNREFERENCED_PARAMETER (SystemArgument1);
//    UNREFERENCED_PARAMETER (SystemArgument2);
//
//    ExFreePool(Apc);
//}
//
//NTSYSAPI
//NTSTATUS
//NTAPI
//NtQueueApcThread(//�˺���û�е�����Ҫ��̬��ȡ��
//    __in HANDLE ThreadHandle,
//    __in PPS_APC_ROUTINE ApcRoutine,
//    __in_opt PVOID ApcArgument1,
//    __in_opt PVOID ApcArgument2,
//    __in_opt PVOID ApcArgument3
//    )

/*++

Routine Description:

    This function is used to queue a user-mode APC to the specified thread. The APC
    will fire when the specified thread does an alertable wait

Arguments:

    ThreadHandle - Supplies a handle to a thread object.  The caller
        must have THREAD_SET_CONTEXT access to the thread.

    ApcRoutine - Supplies the address of the APC routine to execute when the
        APC fires.

    ApcArgument1 - Supplies the first PVOID passed to the APC

    ApcArgument2 - Supplies the second PVOID passed to the APC

    ApcArgument3 - Supplies the third PVOID passed to the APC

Return Value:

    Returns an NT Status code indicating success or failure of the API

--*/

//{
//    PETHREAD Thread;
//    NTSTATUS st;
//    KPROCESSOR_MODE Mode;
//    PKAPC Apc;
//
//    PAGED_CODE();
//
//    Mode = KeGetPreviousMode ();
//
//    st = ObReferenceObjectByHandle (ThreadHandle,
//                                    THREAD_SET_CONTEXT,
//                                    PsThreadType,
//                                    Mode,
//                                    &Thread,
//                                    NULL);
//    if (NT_SUCCESS (st)) {
//        st = STATUS_SUCCESS;
//        if (IS_SYSTEM_THREAD (Thread)) {
//            st = STATUS_INVALID_HANDLE;
//        } else {
//            Apc = ExAllocatePoolWithQuotaTag (NonPagedPool | POOL_QUOTA_FAIL_INSTEAD_OF_RAISE,
//                                              sizeof(*Apc),
//                                              'pasP');
//
//            if (Apc == NULL) {
//                st = STATUS_NO_MEMORY;
//            } else {
//                KeInitializeApc (Apc,
//                                 &Thread->Tcb,
//                                 OriginalApcEnvironment,
//                                 PspQueueApcSpecialApc,
//                                 NULL,
//                                 (PKNORMAL_ROUTINE)ApcRoutine,
//                                 UserMode,
//                                 ApcArgument1);
//
//                if (!KeInsertQueueApc (Apc, ApcArgument2, ApcArgument3, 0)) {
//                    ExFreePool (Apc);
//                    st = STATUS_UNSUCCESSFUL;
//                }
//            }
//        }
//        ObDereferenceObject (Thread);
//    }
//
//    return st;
//}

//////////////////////////////////////////////////////////////////////////////////////////////////

//2008�汾��MSDN����WDK��
//http://msdn.microsoft.com/en-us/library/windows/desktop/ms687420(v=vs.85).aspx
//�����һЩ��ע�ڵͰ汾�ϵ�WDK������
NTSTATUS /* WINAPI */ ZwQueryInformationProcess(
  __in          HANDLE ProcessHandle,
  __in          PROCESSINFOCLASS ProcessInformationClass,
  __out         PVOID ProcessInformation,
  __in          ULONG ProcessInformationLength,
  __out_opt     PULONG ReturnLength
);


/*
һ�¶���ժ�ԣ�
C:\Program Files (x86)\Windows Kits\8.0\Include\um\winternl.h����
C:\Program Files (x86)\Microsoft SDKs\Windows\v7.1A\Include\winternl.h
�������Ϣ���ɿ���
http://undocumented.ntinternals.net/UserMode/Undocumented%20Functions/System%20Information/SYSTEM_INFORMATION_CLASS.html#SystemProcessInformation
http://doxygen.reactos.org/d2/d5c/ntddk__ex_8h_source.html
*/
typedef enum _SYSTEM_INFORMATION_CLASS {
    SystemBasicInformation = 0,
    SystemPerformanceInformation = 2,
    SystemTimeOfDayInformation = 3,
    SystemProcessInformation = 5,
    SystemProcessorPerformanceInformation = 8,
    SystemInterruptInformation = 23,
    SystemExceptionInformation = 33,
    SystemRegistryQuotaInformation = 37,
    SystemLookasideInformation = 45
} SYSTEM_INFORMATION_CLASS;


/*
һ�¶���ժ�ԣ�
C:\Program Files (x86)\Windows Kits\8.0\Include\um\winternl.h����
C:\Program Files (x86)\Microsoft SDKs\Windows\v7.1A\Include\winternl.h ����
http://msdn.microsoft.com/en-us/library/windows/desktop/ms724509(v=vs.85).aspx
ע�������NtQuerySystemInformation�õġ�
*/
//typedef struct _SYSTEM_PROCESS_INFORMATION {
//    ULONG NextEntryOffset;
//    BYTE Reserved1[52];
//    PVOID Reserved2[3];
//    HANDLE UniqueProcessId;
//    PVOID Reserved3;
//    ULONG HandleCount;
//    BYTE Reserved4[4];
//    PVOID Reserved5[11];
//    SIZE_T PeakPagefileUsage;
//    SIZE_T PrivatePageCount;
//    LARGE_INTEGER Reserved6[6];
//} SYSTEM_PROCESS_INFORMATION, *PSYSTEM_PROCESS_INFORMATION;

/*
�����ZwQuerySystemInformation�õĽṹ��
http://msdn.microsoft.com/en-us/library/windows/desktop/ms725506(v=vs.85).aspx
*/
//typedef struct _SYSTEM_PROCESS_INFORMATION {
//    ULONG NextEntryOffset;
//    ULONG NumberOfThreads;
//    BYTE Reserved1[48];
//    PVOID Reserved2[3];
//    HANDLE UniqueProcessId;
//    PVOID Reserved3;
//    ULONG HandleCount;
//    BYTE Reserved4[4];
//    PVOID Reserved5[11];
//    SIZE_T PeakPagefileUsage;
//    SIZE_T PrivatePageCount;
//    LARGE_INTEGER Reserved6[6];
//} SYSTEM_PROCESS_INFORMATION;

/*
ժ�ԣ�http://msdn.microsoft.com/en-us/library/windows/desktop/ms724509(v=vs.85).aspx��
���޸ġ�
*/
NTSTATUS /* WINAPI NtQuerySystemInformation */ ZwQuerySystemInformation(
  _In_       SYSTEM_INFORMATION_CLASS SystemInformationClass,
  _Inout_    PVOID SystemInformation,
  _In_       ULONG SystemInformationLength,
  _Out_opt_  PULONG ReturnLength
);


//ժ�ԣ�http://msdn.microsoft.com/en-us/library/gg750724.aspx ���WRKҲ�еġ�
typedef struct {
  LARGE_INTEGER KernelTime;
  LARGE_INTEGER UserTime;
  LARGE_INTEGER CreateTime;
  ULONG WaitTime;
  PVOID StartAddress;
  CLIENT_ID ClientId;
  LONG Priority;
  LONG BasePriority;
  ULONG ContextSwitches;
  ULONG ThreadState;
  ULONG WaitReason;
} SYSTEM_THREAD_INFORMATION, *PSYSTEM_THREAD_INFORMATION;


//ժ�ԣ�http://doxygen.reactos.org/de/d22/ndk_2extypes_8h_source.html�����޸ġ�
typedef struct _SYSTEM_PROCESS_INFORMATION
{
     ULONG NextEntryOffset;
     ULONG NumberOfThreads;
     LARGE_INTEGER WorkingSetPrivateSize; //VISTA
     ULONG HardFaultCount; //WIN7
     ULONG NumberOfThreadsHighWatermark; //WIN7
     ULONGLONG CycleTime; //WIN7
     LARGE_INTEGER CreateTime;
     LARGE_INTEGER UserTime;
     LARGE_INTEGER KernelTime;
     UNICODE_STRING ImageName;//������ֺ��񲻳���15-16���ַ���
     KPRIORITY BasePriority;
     HANDLE UniqueProcessId;
     HANDLE InheritedFromUniqueProcessId;
     ULONG HandleCount;
     ULONG SessionId;
     ULONG_PTR PageDirectoryBase;
 
     //
     // This part corresponds to VM_COUNTERS_EX.
     // NOTE: *NOT* THE SAME AS VM_COUNTERS!
     //
     SIZE_T PeakVirtualSize;
     SIZE_T VirtualSize;
     ULONG PageFaultCount;
     SIZE_T PeakWorkingSetSize;
     SIZE_T WorkingSetSize;
     SIZE_T QuotaPeakPagedPoolUsage;
     SIZE_T QuotaPagedPoolUsage;
     SIZE_T QuotaPeakNonPagedPoolUsage;
     SIZE_T QuotaNonPagedPoolUsage;
     SIZE_T PagefileUsage;
     SIZE_T PeakPagefileUsage;
     SIZE_T PrivatePageCount;
 
     //
     // This part corresponds to IO_COUNTERS
     //
     LARGE_INTEGER ReadOperationCount;
     LARGE_INTEGER WriteOperationCount;
     LARGE_INTEGER OtherOperationCount;
     LARGE_INTEGER ReadTransferCount;
     LARGE_INTEGER WriteTransferCount;
     LARGE_INTEGER OtherTransferCount;
     SYSTEM_THREAD_INFORMATION TH[1];//���������ע�͵��ġ�
} SYSTEM_PROCESS_INFORMATION, *PSYSTEM_PROCESS_INFORMATION;



//http://msdn.microsoft.com/en-us/library/cc248685.aspx
typedef struct _NT6_TS_UNICODE_STRING {
  USHORT Length;
  USHORT MaximumLength;
  //[size_is(MaximumLength/2), length_is(Length/2)] 
  PWSTR Buffer;
} NT6_TS_UNICODE_STRING;


/*
http://msdn.microsoft.com/en-us/library/cc248684.aspx
http://msdn.microsoft.com/en-us/library/cc248873.aspx ����allproc.h������WDK��WRK���涼û�У�ע��wdk8.1��û�а�װ��
*/
typedef struct _TS_SYS_PROCESS_INFORMATION_NT6 {
  ULONG NextEntryOffset;
  ULONG NumberOfThreads;
  LARGE_INTEGER SpareLi1;
  LARGE_INTEGER SpareLi2;
  LARGE_INTEGER SpareLi3;
  LARGE_INTEGER CreateTime;
  LARGE_INTEGER UserTime;
  LARGE_INTEGER KernelTime;
  NT6_TS_UNICODE_STRING ImageName;
  LONG BasePriority;
  DWORD UniqueProcessId;
  DWORD InheritedFromUniqueProcessId;
  ULONG HandleCount;
  ULONG SessionId;
  ULONG SpareUl3;
  SIZE_T PeakVirtualSize;
  SIZE_T VirtualSize;
  ULONG PageFaultCount;
  ULONG PeakWorkingSetSize;
  ULONG WorkingSetSize;
  SIZE_T QuotaPeakPagedPoolUsage;
  SIZE_T QuotaPagedPoolUsage;
  SIZE_T QuotaPeakNonPagedPoolUsage;
  SIZE_T QuotaNonPagedPoolUsage;
  SIZE_T PagefileUsage;
  SIZE_T PeakPagefileUsage;
  SIZE_T PrivatePageCount;

  //����ṹ��SYSTEM_PROCESS_INFORMATION��࣬������������Щ��
} TS_SYS_PROCESS_INFORMATION_NT6, *PTS_SYS_PROCESS_INFORMATION_NT6;


//////////////////////////////////////////////////////////////////////////////////////////////////

typedef
    int (NTAPI * MessageBoxT)( 
    HWND hWnd,
    LPCTSTR lpText,
    LPCTSTR lpCaption,
    UINT uType
    );

//////////////////////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable:4700)//ʹ����δ��ʼ���ľֲ�������UserRoutine��

//////////////////////////////////////////////////////////////////////////////////////////////////


/*
ժ�ԣ�http://msdn.microsoft.com/en-us/library/windows/desktop/aa813708(v=vs.85).aspx
*/
typedef struct _LDR_DATA_TABLE_ENTRY {
    PVOID Reserved1[2];
    LIST_ENTRY InMemoryOrderLinks;
    PVOID Reserved2[2];
    PVOID DllBase;
    PVOID EntryPoint;
    PVOID Reserved3;
    UNICODE_STRING FullDllName;
    BYTE Reserved4[8];
    PVOID Reserved5[3];
    union {
        ULONG CheckSum;
        PVOID Reserved6;
    };
    ULONG TimeDateStamp;
} LDR_DATA_TABLE_ENTRY, *PLDR_DATA_TABLE_ENTRY;


/*
ժ�ԣ�\wrk\WindowsResearchKernel-WRK\WRK-v1.2\base\ntos\inc\ps.h
�˺�����XP 32�Ͼ��Ѿ�������Ӧ�ÿ��Է���ʹ�á�
����ZwQueryInformationProcess �� ProcessBasicInformation.
*/
NTKERNELAPI
PPEB
PsGetProcessPeb(
    __in PEPROCESS Process
    );



//ժ�ԣ�http://msdn.microsoft.com/en-us/library/windows/desktop/aa813708(v=vs.85).aspx
typedef struct _PEB_LDR_DATA {
  BYTE       Reserved1[8];
  PVOID      Reserved2[3];
  LIST_ENTRY InMemoryOrderModuleList;
} PEB_LDR_DATA, *PPEB_LDR_DATA;


//http://msdn.microsoft.com/en-us/library/windows/desktop/aa813741(v=vs.85).aspx
typedef struct _RTL_USER_PROCESS_PARAMETERS {
  BYTE           Reserved1[16];
  PVOID          Reserved2[10];
  UNICODE_STRING ImagePathName;
  UNICODE_STRING CommandLine;
} RTL_USER_PROCESS_PARAMETERS, *PRTL_USER_PROCESS_PARAMETERS;


//ժ�ԣ�Winternl.h��
typedef
VOID
(NTAPI *PPS_POST_PROCESS_INIT_ROUTINE) (
    VOID
    );


#ifdef _X86_
typedef struct _PEB {
    BYTE                          Reserved1[2];
    BYTE                          BeingDebugged;
    BYTE                          Reserved2[1];
    PVOID                         Reserved3[2];
    PPEB_LDR_DATA                 Ldr;
    PRTL_USER_PROCESS_PARAMETERS  ProcessParameters;
    BYTE                          Reserved4[104];
    PVOID                         Reserved5[52];
    PPS_POST_PROCESS_INIT_ROUTINE PostProcessInitRoutine;
    BYTE                          Reserved6[128];
    PVOID                         Reserved7[1];
    ULONG                         SessionId;
} PEB, *PPEB;    
#endif
//���µĽṹ���壬ժ�ԣ�http://msdn.microsoft.com/en-us/library/windows/desktop/aa813706(v=vs.85).aspx
#if defined(_WIN64)
typedef struct _PEB {
    BYTE Reserved1[2];
    BYTE BeingDebugged;
    BYTE Reserved2[21];
    PPEB_LDR_DATA Ldr;//LoaderData;
    PRTL_USER_PROCESS_PARAMETERS ProcessParameters;
    BYTE Reserved3[520];
    PPS_POST_PROCESS_INIT_ROUTINE PostProcessInitRoutine;
    BYTE Reserved4[136];
    ULONG SessionId;
} PEB;    
#endif 


PVOID RtlImageDirectoryEntryToData (IN PVOID Base, IN BOOLEAN MappedAsImage, IN USHORT DirectoryEntry, OUT PULONG Size);


//////////////////////////////////////////////////////////////////////////////////////////////////


typedef
HMODULE (WINAPI * LoadLibraryT)(
  __in          LPCTSTR lpFileName
);

typedef NTSTATUS (WINAPI * ZwFreeVirtualMemoryT)(
    __in HANDLE  ProcessHandle,
    __inout PVOID  *BaseAddress,
    __inout PSIZE_T  RegionSize,
    __in ULONG  FreeType
    ); 

typedef struct _PassToUser{
    PVOID ntdll;
    PVOID kernel32;
    PVOID user32;
    PVOID advapi32;
    PVOID KernelBase;

    LoadLibraryT LoadLibraryW;
    PVOID GetProcAddress;
    PVOID LdrLoadDll;
    ZwFreeVirtualMemoryT NtFreeVirtualMemory;

    wchar_t FullDllPathName[MAX_PATH]; 
    wchar_t OtherData[MAX_PATH]; 

    SIZE_T RegionSize;

    BOOLEAN done;
} PassToUser, *PPassToUser;


//////////////////////////////////////////////////////////////////////////////////////////////////


NTSYSAPI
NTSTATUS
NTAPI
ZwTestAlert (//XP �ں�û�е�����
    VOID
    );


NTSYSAPI
NTSTATUS
NTAPI
ZwAlertThread (//XP �ں˵�����
    __in HANDLE ThreadHandle
    );


NTSYSAPI
NTSTATUS
NTAPI
ZwAlertResumeThread (
    __in HANDLE ThreadHandle,
    __out_opt PULONG PreviousSuspendCount
    );


//NTSTATUS
//NtAlertThread(
//    __in HANDLE ThreadHandle
//    )

/*++

Routine Description:

    This function alerts the target thread using the previous mode
    as the mode of the alert.

Arguments:

    ThreadHandle - Supplies an open handle to the thread to be alerted

Return Value:

    NTSTATUS - Status of operation

--*/

//{
//    PETHREAD Thread;
//    NTSTATUS st;
//    KPROCESSOR_MODE Mode;
//
//    PAGED_CODE();
//
//    Mode = KeGetPreviousMode ();
//
//    st = ObReferenceObjectByHandle (ThreadHandle,
//                                    THREAD_ALERT,
//                                    PsThreadType,
//                                    Mode,
//                                    &Thread,
//                                    NULL);
//
//    if (!NT_SUCCESS (st)) {
//        return st;
//    }
//
//    KeAlertThread (&Thread->Tcb,Mode);
//
//    ObDereferenceObject (Thread);
//
//    return STATUS_SUCCESS;
//
//}


//NTSTATUS
//NtTestAlert(
//    VOID
//    )

/*++

Routine Description:

    This function tests the alert flag inside the current thread. If
    an alert is pending for the previous mode, then the alerted status
    is returned, pending APC's may also be delivered at this time.

Arguments:

    None

Return Value:

    STATUS_ALERTED - An alert was pending for the current thread at the
        time this function was called.

    STATUS_SUCCESS - No alert was pending for this thread.

--*/

//{
//
//    PAGED_CODE();
//
//    if (KeTestAlertThread(KeGetPreviousMode ())) {
//        return STATUS_ALERTED;
//    } else {
//        return STATUS_SUCCESS;
//    }
//}


//////////////////////////////////////////////////////////////////////////////////////////////////