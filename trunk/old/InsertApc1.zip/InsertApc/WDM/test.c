﻿#include "test.h"


/*
功能：在驱动中用APC注入一段代码到某个进程中运行。

做法：倒是很简单就一个函数，如：NtQueueApcThread，但是这个函数没有导出，但可以动态获取。而且还有导出的KeInsertQueueApc之类的函数实现类似的功能。

进程，要排除IDLE，SYSTEM。smss.exe最好也排除，除非只用NTDLL.DLL的函数，但是加载其他DLL也可以的。

对于X64及X64中的WOW64需要再做改进/修改。

插入了，何时运行还未知：快的需要几秒，慢的需要及分钟，甚至几十分钟，更深的几个小时或者几天几夜，甚至永远不会运行，如：不触发或者线程的状态不符合。

类似的办法还有：
1.IMAGE回调。
2.KernelCallbackTable = apfnDispatch
3.自己手动创建线程，要考虑X86，X64/WOW64等。

APC应该是一个不会取消的功能，因为：
1.引用层有：QueueUserAPC。
2.内核的DPC函数倒是公开了，如：KeInitializeDpc/KeInsertQueueDpc/KeRemoveQueueDpc。

本文是测试代码，尽管尽量规范的去写，但是还有一些BUG，如卸载等。

参考：
1.WRK
2.http://www.microsoft.com/msj/0799/nerd/nerd0799.aspx
3.http://www.rohitab.com/discuss/topic/40737-inject-dll-from-kernel-mode/
还有一份俄国的，写的也不错。

made by correy
made at 2015.12.25
http://correy.webs.com 
*/


BOOLEAN g_b = TRUE;
MessageBoxT g_MessageBox = 0;
SIZE_T ApcStateOffset; 

WCHAR g_FullDllPathName[MAX_PATH];//存储对象管理器中的沙盒目录。
UNICODE_STRING g_us_FullDllPathName;//主要就是存储上面的路径。形如："ahsh"

PVOID MiFindExportedRoutineByName (IN PVOID DllBase, IN PANSI_STRING AnsiImageRoutineName);

//////////////////////////////////////////////////////////////////////////////////////////////////


BOOL GetProcessImageFileName(IN HANDLE PId, OUT UNICODE_STRING * file_name )
{
    NTSTATUS status = 0;
    PVOID us_ProcessImageFileName = 0;//UNICODE_STRING
    ULONG ProcessInformationLength = 0;
    ULONG ReturnLength = 0;
    PEPROCESS  EProcess = 0;
    HANDLE  Handle = 0;
    UNICODE_STRING * p = {0};
    UNICODE_STRING temp = {0};
    USHORT i = 0;

    /*
    必须转换一下，不然是无效的句柄。
    大概是句柄的类型转换为内核的。
    */
    status = PsLookupProcessByProcessId(PId, &EProcess);
    if (!NT_SUCCESS( status )) 
    {
        KdPrint(("PsLookupProcessByProcessId fail with 0x%x in line %d\n",status, __LINE__));
        return FALSE ;        
    }
    ObDereferenceObject(EProcess); //微软建议加上。
    status = ObOpenObjectByPointer(EProcess, OBJ_KERNEL_HANDLE, NULL, GENERIC_READ, *PsProcessType, KernelMode, &Handle);//注意要关闭句柄。  
    if (!NT_SUCCESS( status )) 
    {
        KdPrint(("ObOpenObjectByPointer fail with 0x%x in line %d\n",status, __LINE__));
        return FALSE;        
    }

    //获取需要的内存。
    status = ZwQueryInformationProcess(Handle, ProcessImageFileName,us_ProcessImageFileName, ProcessInformationLength, &ReturnLength);
    if( !NT_SUCCESS( status ) && status != STATUS_INFO_LENGTH_MISMATCH)
    { 
        KdPrint(("ZwQueryInformationProcess fail with 0x%x in line %d\n",status, __LINE__));
        ZwClose(Handle);
        return FALSE ;
    }
    ProcessInformationLength = ReturnLength;
    us_ProcessImageFileName = ExAllocatePoolWithTag( NonPagedPool, ReturnLength, TAG);
    if (us_ProcessImageFileName == NULL) {
        KdPrint(("ExAllocatePoolWithTag fail with 0x%x\n",status));
        status = STATUS_INSUFFICIENT_RESOURCES;
        ZwClose(Handle);
        return FALSE ;
    }
    RtlZeroMemory(us_ProcessImageFileName, ReturnLength);

    status = ZwQueryInformationProcess(Handle, ProcessImageFileName,us_ProcessImageFileName, ProcessInformationLength, &ReturnLength);
    if( !NT_SUCCESS( status ))
    {
        KdPrint(("ZwQueryInformationProcess fail with 0x%x in line %d\n",status, __LINE__));
        ExFreePoolWithTag( us_ProcessImageFileName, TAG );
        ZwClose(Handle);
        return FALSE ;
    }

    //KdPrint(("ProcessImageFileName:%wZ\n",us_ProcessImageFileName));//注意：中间有汉字是不会显示的。
    //形如：ProcessImageFileName:\Device\HarddiskVolume1\aa\Dbgvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvview.exe
    p = (UNICODE_STRING *)us_ProcessImageFileName;

    if (p->Length == 0)
    {
        KdPrint(("p->Length == 0 in line %d\n", __LINE__));
        ExFreePoolWithTag( us_ProcessImageFileName, TAG );
        ZwClose(Handle);
        return FALSE ;
    }

    //从末尾开始搜索斜杠。
    for (i = p->Length/2 - 1 ; ;i-- )
    {
        if (p->Buffer[i] == L'\\')
        {
            break;
        }
    }

    i++;//跳过斜杠。

    //构造文件名结构，复制用的。
    temp.Length = p->Length - i * 2;
    temp.MaximumLength = p->MaximumLength - i * 2;
    temp.Buffer = &p->Buffer[i];

    //这个内存由调用者释放。
    file_name->Buffer = ExAllocatePoolWithTag(NonPagedPool, MAX_PATH, TAG);
    if (file_name->Buffer == NULL) { 
        DbgPrint("发生错误的文件为:%s, 代码行为:%d\n", __FILE__, __LINE__);
        ExFreePoolWithTag( us_ProcessImageFileName, TAG );
        ZwClose(Handle);
        return FALSE ;
    }
    RtlZeroMemory(file_name->Buffer, MAX_PATH);
    RtlInitEmptyUnicodeString(file_name, file_name->Buffer,MAX_PATH);

    RtlCopyUnicodeString(file_name, &temp);
    //KdPrint(("ProcessImageFileName:%wZ\n",file_name));

    ExFreePoolWithTag( us_ProcessImageFileName, TAG );
    ZwClose(Handle);
    return TRUE ;
}


NTSTATUS GetPidFromProcessName(IN PWCH ProcessName, OUT HANDLE * UniqueProcessId)
    /*
    功能：根据进程名获取PID。
    作用：1.测试常用。
          2.对于根据进程的名操作，如：根据进程名结束进程等。
    说明：1.如果指定的进程名有多个只返回一个。
          2.如果指定的进程名不存在，返回STATUS_INVALID_HANDLE;//STATUS_UNSUCCESSFUL。
    话外题：这个目的还有别的好办法吗？
            1.ZwOpenProcess好像是最直接的函数，但是总是失败。
            2.暴力枚举进程还不如本办法的ZwQuerySystemInformation + SystemProcessInformation，别的枚举进程方法类似。
    */
{
    NTSTATUS status = STATUS_UNSUCCESSFUL; 
    SYSTEM_PROCESS_INFORMATION * pspi = 0;
    SYSTEM_PROCESS_INFORMATION * pspi_temp = 0;
    ULONG SystemInformationLength = 0;
    ULONG ReturnLength = 0;
    UNICODE_STRING usProcessName = {0};

    //参数检查就不做了。

    * UniqueProcessId = ULongToHandle(STATUS_INVALID_HANDLE);//默认设置。有可能找不到，也就是不存在。

    RtlInitUnicodeString(&usProcessName, ProcessName);
    
    //获取需要的内存。
    status = ZwQuerySystemInformation(SystemProcessInformation, pspi, SystemInformationLength, &ReturnLength);
    if( !NT_SUCCESS( status ) && status != STATUS_INFO_LENGTH_MISMATCH)
    { 
        KdPrint(("ZwQuerySystemInformation fail with 0x%x in line %d\n",status, __LINE__));
        return status;
    }
    ReturnLength *= 2;//第一次需求0x9700，第二次需求0x9750,所以乘以2.
    SystemInformationLength = ReturnLength;
    pspi = ExAllocatePoolWithTag( NonPagedPool, ReturnLength, TAG);
    if (pspi == NULL) {
        KdPrint(("ExAllocatePoolWithTag fail with 0x%x\n",status));
        return STATUS_INSUFFICIENT_RESOURCES;
    }
    RtlZeroMemory(pspi, ReturnLength);    

    status = ZwQuerySystemInformation(SystemProcessInformation, pspi, SystemInformationLength, &ReturnLength);
    if( !NT_SUCCESS( status ) )
    {
        KdPrint(("ZwQuerySystemInformation fail with 0x%x in line %d\n",status, __LINE__));
        ExFreePoolWithTag( pspi, TAG );
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    for (pspi_temp = pspi ; /* pspi_temp->NextEntryOffset != 0 */; /*pspi_temp++*/) //注释的都是有问题的，如少显示一个等。
    {
        UNICODE_STRING file_name;
        BOOL B = GetProcessImageFileName(pspi_temp->UniqueProcessId,  &file_name );
        if (B)
        {
            //DbgPrint( "GetProcessImageFileName fail!\n");
            //continue;

            if (RtlCompareUnicodeString(&file_name, &usProcessName, TRUE) == 0)
            {
                RtlFreeUnicodeString(&file_name);
                * UniqueProcessId = pspi_temp->UniqueProcessId;
                break;
            }

            RtlFreeUnicodeString(&file_name);
        }         

        //KdPrint(("PID:%d\tNumberOfThreads:%d\tHandleCount:%d\n",pspi_temp->UniqueProcessId, pspi_temp->NumberOfThreads, pspi_temp->HandleCount));
        
        /*
        The start of the next item in the array is the address of the previous item plus the value in the NextEntryOffset member. 
        For the last item in the array, NextEntryOffset is 0.
        摘自：http://msdn.microsoft.com/en-us/library/windows/desktop/ms724509(v=vs.85).aspx。
        说明：NextEntryOffset的值是不固定的，更不是SYSTEM_PROCESS_INFORMATION结构的大小。所以不能加一个结构的大小来遍历。
        */

        if (pspi_temp->NextEntryOffset == 0)
        {
            break;
        }

        pspi_temp = (SYSTEM_PROCESS_INFORMATION *)((char *)pspi_temp + pspi_temp->NextEntryOffset);
    }

    if (* UniqueProcessId == ULongToHandle(STATUS_INVALID_HANDLE))
    {//进程名不存在，没有找到。
        status = STATUS_INVALID_HANDLE;//STATUS_UNSUCCESSFUL
    }

    ExFreePoolWithTag( pspi, TAG );

    return status;//STATUS_SUCCESS
} 


void KMApcCallback(PKAPC Apc, PKNORMAL_ROUTINE NormalRoutine, PVOID NormalContext, PVOID SystemArgument1, PVOID SystemArgument2)
    /*
    估计，卸载后发生了APC，会蓝在这里。所以要同步，确保APC发生。
    */
{
    ExFreePool(Apc);
    return;
}


void ApcCallback(PVOID NormalContext, PVOID SystemArgument1, PVOID SystemArgument2)
    /*
    要复制给用户态的代码。

    建议这里释放驱动中申请的用户态内存。
    */
{ 
    //wchar_t Caption[16] = L"Caption";
    //wchar_t Text[16] = L"Text";
    //wchar_t DllFullPathName[260] = L"XXX";//其实这里可以来个LoadLibrary，这样就成注入DLL了。

    MessageBoxT MessageBox = (MessageBoxT) SystemArgument1;
    PPassToUser pa2 = (PPassToUser)SystemArgument2;

    __debugbreak();  

    //MessageBox = (MessageBoxT) SystemArgument1;//测试用的。

    //MessageBox(0, 0, 0, 0);//OK 
    //MessageBox(0, (LPCTSTR)&Text[0], (LPCTSTR)&Caption[0], 0);

    pa2->LoadLibraryW(pa2->FullDllPathName);

    pa2->done = 1;
    
    //g_MessageBox(0, 0, 0, 0);//这个总是调用函数地址所在地址的地址，这个地址内核的。C语言不好，没有想出相应的解决办法。
}
void ApcCallbackEnd()
{

}



VOID InitialUserRoutine(PCLIENT_ID ClientId, SIZE_T * pApcCallbackAddr)
    /*
    申请用户态的内存，并把代码复制过去。
    */
{
    PEPROCESS    m_process;
    NTSTATUS     status = STATUS_SUCCESS;
    KAPC_STATE   m_kapc_state;
    SIZE_T size = 0;
    PVOID BaseAddress = 0;//必须制定为0，否则返回参数错误。
    HANDLE  Handle = 0;
    SIZE_T code_size = 0;

    status=PsLookupProcessByProcessId(ClientId->UniqueProcess, &m_process);//得到指定进程ID的进程环境块
    ASSERT (NT_SUCCESS(status));

    status = ObOpenObjectByPointer(m_process, OBJ_KERNEL_HANDLE, NULL, GENERIC_ALL, *PsProcessType, KernelMode, &Handle);//注意要关闭句柄。  
    ASSERT (NT_SUCCESS(status));    

    if (((SIZE_T)ApcCallbackEnd - (SIZE_T)ApcCallback) > 0)
    {
        size = (SIZE_T)ApcCallbackEnd - (SIZE_T)ApcCallback;
    }
    else
    {
        size = (SIZE_T)ApcCallback - (SIZE_T)ApcCallbackEnd;    
    }

    code_size = size;

    status = ZwAllocateVirtualMemory(Handle  /*NtCurrentProcess()*/, &BaseAddress, 0, &size, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    ASSERT (NT_SUCCESS(status)); 

    KeStackAttachProcess (m_process, &m_kapc_state); //附加当前线程到目标进程空间内   
    __try 
    {        
        RtlZeroMemory(BaseAddress, code_size);
        RtlCopyMemory(BaseAddress, ApcCallback, code_size);         
    }
    __except(EXCEPTION_EXECUTE_HANDLER)
    {
        KdBreakPoint();
    }    
    KeUnstackDetachProcess(&m_kapc_state);//解除附加

    * pApcCallbackAddr = (SIZE_T)BaseAddress;    

    ObDereferenceObject(m_process);
    ZwClose(Handle);
}


void BuildDLL()
{
    wchar_t * test = L"c:\\dll.dll";
    int length = wcslen(test) * sizeof(wchar_t);

    RtlCopyMemory(g_FullDllPathName, test, length);
    g_us_FullDllPathName.Buffer = g_FullDllPathName;
    g_us_FullDllPathName.Length = wcslen(g_FullDllPathName) * sizeof(wchar_t);
    g_us_FullDllPathName.MaximumLength = wcslen(g_FullDllPathName) * sizeof(wchar_t);
}


VOID InitialUserArgument(HANDLE UniqueProcess, SIZE_T * pud)
    /*
    
    */
{
    PEPROCESS    m_process;
    NTSTATUS     status = STATUS_SUCCESS;
    KAPC_STATE   m_kapc_state;
    SIZE_T size = 0;
    PVOID BaseAddress = 0;//必须制定为0，否则返回参数错误。
    HANDLE  Handle = 0;
    SIZE_T code_size = 0;
    PassToUser * pUserData = NULL;

    PPEB         ppeb;
    PLDR_DATA_TABLE_ENTRY pldte;
    PLIST_ENTRY le1,le2;
    UNICODE_STRING ntdll = RTL_CONSTANT_STRING(L"ntdll.dll");
    UNICODE_STRING kernel32 = RTL_CONSTANT_STRING(L"kernel32.dll");
    UNICODE_STRING user32 = RTL_CONSTANT_STRING(L"user32.dll");
    UNICODE_STRING advapi32 = RTL_CONSTANT_STRING(L"advapi32.dll");
    UNICODE_STRING KernelBase = RTL_CONSTANT_STRING(L"KernelBase.dll");
    PUNICODE_STRING pus = NULL;

    status=PsLookupProcessByProcessId(UniqueProcess, &m_process);//得到指定进程ID的进程环境块
    ASSERT (NT_SUCCESS(status));

    status = ObOpenObjectByPointer(m_process, OBJ_KERNEL_HANDLE, NULL, GENERIC_ALL, *PsProcessType, KernelMode, &Handle);//注意要关闭句柄。  
    ASSERT (NT_SUCCESS(status));    

    size = sizeof(PassToUser);
    code_size = size;

    status = ZwAllocateVirtualMemory(Handle, &BaseAddress, 0, &size, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    ASSERT (NT_SUCCESS(status)); 

    KeStackAttachProcess (m_process, &m_kapc_state); //附加当前线程到目标进程空间内   

    RtlZeroMemory(BaseAddress, code_size);
    pUserData = (PPassToUser)BaseAddress;

    ppeb = PsGetProcessPeb(m_process);//注意：IDLE和system这两个应该获取不到。
    le1 = ppeb->Ldr->InMemoryOrderModuleList.Flink;
    le2 = le1 ;
    do 
    {
        pldte = (PLDR_DATA_TABLE_ENTRY)CONTAINING_RECORD(le1, LDR_DATA_TABLE_ENTRY, InMemoryOrderLinks);
        if (pldte->FullDllName.Length) //过滤掉最后一个，多余的。
        {
            //KdPrint(("FullDllName:%wZ \n", &pldte->FullDllName));//"C:\WINDOWS\system32\USER32.dll"，因为这里是完整路径，另一个思路是获取系统路径再组合。

            pus = (PUNICODE_STRING)&pldte->Reserved4;
            //if (RtlCompareUnicodeString(&pldte->FullDllName, &user32, TRUE) == 0)
            
            if (RtlCompareUnicodeString(pus, &ntdll, TRUE) == 0)
            {
                ANSI_STRING NtFreeVirtualMemory  = RTL_CONSTANT_STRING("NtFreeVirtualMemory");

                pUserData->ntdll = pldte->DllBase; 

                pUserData->NtFreeVirtualMemory = MiFindExportedRoutineByName (pldte->DllBase, &NtFreeVirtualMemory);
                ASSERT(pUserData->NtFreeVirtualMemory);
                //break;
            }

            if (RtlCompareUnicodeString(pus, &kernel32, TRUE) == 0)
            {
                ANSI_STRING LoadLibraryW  = RTL_CONSTANT_STRING("LoadLibraryW");
                ANSI_STRING GetProcAddress  = RTL_CONSTANT_STRING("GetProcAddress");

                pUserData->kernel32 = pldte->DllBase; 

                pUserData->LoadLibraryW = MiFindExportedRoutineByName (pldte->DllBase, &LoadLibraryW);
                ASSERT(pUserData->LoadLibraryW);
                
                pUserData->GetProcAddress = MiFindExportedRoutineByName (pldte->DllBase, &GetProcAddress);
                ASSERT(pUserData->GetProcAddress);
            }

            if (RtlCompareUnicodeString(pus, &user32, TRUE) == 0)
            {
                ANSI_STRING test  = RTL_CONSTANT_STRING("MessageBoxW");

                pUserData->user32 = pldte->DllBase; 

                //g_MessageBox = (MessageBoxT)MiFindExportedRoutineByName (pldte->DllBase, &test);
                //ASSERT(g_MessageBox);
                //break;
            }

            if (RtlCompareUnicodeString(pus, &advapi32, TRUE) == 0)
            {
                ANSI_STRING test  = RTL_CONSTANT_STRING("MessageBoxW");

                pUserData->advapi32 = pldte->DllBase; 

                //g_MessageBox = (MessageBoxT)MiFindExportedRoutineByName (pldte->DllBase, &test);
                //ASSERT(g_MessageBox);
                //break;
            }

            if (RtlCompareUnicodeString(pus, &KernelBase, TRUE) == 0)
            {
                ANSI_STRING test  = RTL_CONSTANT_STRING("MessageBoxW");

                pUserData->KernelBase = pldte->DllBase; 

                //g_MessageBox = (MessageBoxT)MiFindExportedRoutineByName (pldte->DllBase, &test);
                //ASSERT(g_MessageBox);
                //break;
            }
        }
        le1 = le1->Flink;
    }while (le1 != le2);

    BuildDLL();
    RtlCopyMemory(pUserData->FullDllPathName, g_us_FullDllPathName.Buffer, g_us_FullDllPathName.Length);

    //__try 
    //{ 
    //    /*RtlZeroMemory(BaseAddress, code_size);
    //    
    //    pUserData = (PPassToUser)BaseAddress;*/

    //    //获取和设置里面自己定义的成员吧！
    //    //pUserData->ntdll = 0;
    //    //
    //}
    //__except(EXCEPTION_EXECUTE_HANDLER)
    //{
    //    KdBreakPoint();
    //}    

    KeUnstackDetachProcess(&m_kapc_state);//解除附加

    * pud = (SIZE_T)BaseAddress;    

    ObDereferenceObject(m_process);
    ZwClose(Handle);
}


VOID DoAfterAPC(HANDLE UniqueProcess, PVOID SystemArgument1, PVOID SystemArgument2)
    /*
    
    */
{
    PEPROCESS    m_process;
    NTSTATUS     status = STATUS_SUCCESS;
    KAPC_STATE   m_kapc_state;    
    HANDLE  Handle = 0;

    status=PsLookupProcessByProcessId(UniqueProcess, &m_process);//得到指定进程ID的进程环境块
    ASSERT (NT_SUCCESS(status));

    status = ObOpenObjectByPointer(m_process, OBJ_KERNEL_HANDLE, NULL, GENERIC_ALL, *PsProcessType, KernelMode, &Handle);//注意要关闭句柄。  
    ASSERT (NT_SUCCESS(status));    

    KeStackAttachProcess (m_process, &m_kapc_state); //附加当前线程到目标进程空间内   
    __try 
    { 
        LARGE_INTEGER delay;
        PPassToUser pt = NULL;
        SIZE_T size = 0;

        //其实这里可以用事件会更好。
        delay.QuadPart=-100*10000;
        pt = (PPassToUser)SystemArgument2;
        while(pt->done == 0)
        {
            KeDelayExecutionThread(KernelMode,FALSE,&delay); // Wait for the injection to complete
        }

        //size=0;
        //status = ZwFreeVirtualMemory(NtCurrentProcess(), &SystemArgument1,&size,MEM_RELEASE);
        //ASSERT (NT_SUCCESS(status)); 

        size=0;
        status = ZwFreeVirtualMemory(NtCurrentProcess(), &SystemArgument2,&size,MEM_RELEASE);
        ASSERT (NT_SUCCESS(status)); 
    }
    __except(EXCEPTION_EXECUTE_HANDLER)
    {
        KdBreakPoint();
    }    
    KeUnstackDetachProcess(&m_kapc_state);//解除附加

    ObDereferenceObject(m_process);
    ZwClose(Handle);
}


NTSTATUS QueueApcThread(PCLIENT_ID ClientId)
{
    NTSTATUS status = STATUS_SUCCESS;    
    SIZE_T UserRoutine;// = NULL;
    PETHREAD Thread;
    BOOLEAN B = FALSE;

    if (ClientId->UniqueProcess == 0 || PsGetProcessId(PsInitialSystemProcess) == ClientId->UniqueProcess)
    {
        return FALSE ;
    } 

    InitialUserRoutine(ClientId, &UserRoutine);
    ASSERT(UserRoutine != 0);

    //status = ObReferenceObjectByHandle (ClientId->UniqueThread, THREAD_SET_CONTEXT, *PsThreadType, ExGetPreviousMode (), &Thread, NULL);
    status = PsLookupThreadByThreadId(ClientId->UniqueThread, &Thread);
    if (NT_SUCCESS (status))
    {
        status = STATUS_SUCCESS;
        if (PsIsSystemThread (Thread)) {
            status = STATUS_INVALID_HANDLE;
        } else {
            PKAPC Apc;
            PKAPC_STATE ApcState;
            SIZE_T pud = 0;   
            HANDLE KernelHandle;

            //ApcState=(PKAPC_STATE)((PSIZE_T)Thread + ApcStateOffset); 
            //ApcState->UserApcPending=TRUE; 
            status = ObOpenObjectByPointer(Thread, OBJ_KERNEL_HANDLE, NULL, THREAD_ALERT, *PsThreadType, KernelMode, &KernelHandle);
            ASSERT(NT_SUCCESS(status));
            status = ZwAlertThread(KernelHandle);
            ASSERT(NT_SUCCESS(status));            
            //ZwClose(KernelHandle);

            InitialUserArgument(ClientId->UniqueProcess, &pud);
            ASSERT(pud);

            Apc = ExAllocatePool(NonPagedPool, sizeof(KAPC));
            ASSERT(Apc);
            KeInitializeApc(Apc,
                Thread,//KeGetCurrentThread(),
                OriginalApcEnvironment,
                (PKKERNEL_ROUTINE)&KMApcCallback, // kernel-mode routine
                0,                                // rundown routine
                (PKNORMAL_ROUTINE)UserRoutine,   // user-mode routine 如果注入DLL，此时可以填写LoadLibraryW的地址，但是参数的个数不对。
                UserMode, (PVOID)(ULONG)1);
            B = KeInsertQueueApc(Apc, (PVOID)g_MessageBox, (PVOID)pud, 0);
            ASSERT(B);

            ZwClose(KernelHandle);

            //其实这里可以用事件会更好。
            //等待及善后的工作。
            //这样做不好。
            //DoAfterAPC(ClientId->UniqueProcess, (PVOID)g_MessageBox, (PVOID)pud);
        }
        ObDereferenceObject (Thread);
    }   

    return status;
}


NTSTATUS ProcessAllThread( __in HANDLE UniqueProcessId)
{
    NTSTATUS status = STATUS_UNSUCCESSFUL; 
    SYSTEM_PROCESS_INFORMATION * pspi = 0;
    SYSTEM_PROCESS_INFORMATION * pspi_temp = 0;
    ULONG SystemInformationLength = 0;
    ULONG ReturnLength = 0;
    ULONG i = 0;
    PSYSTEM_THREAD_INFORMATION psti = 0;
    
    //获取需要的内存。
    status = ZwQuerySystemInformation(SystemProcessInformation, pspi, SystemInformationLength, &ReturnLength);
    if( !NT_SUCCESS( status ) && status != STATUS_INFO_LENGTH_MISMATCH)
    { 
        KdPrint(("ZwQuerySystemInformation fail with 0x%x in line %d\n",status, __LINE__));
        return status;
    }
    ReturnLength *= 2;//第一次需求0x9700，第二次需求0x9750,所以乘以2.
    SystemInformationLength = ReturnLength;
    pspi = ExAllocatePoolWithTag( NonPagedPool, ReturnLength, TAG);
    if (pspi == NULL) {
        KdPrint(("ExAllocatePoolWithTag fail with 0x%x\n",status));
        return STATUS_INSUFFICIENT_RESOURCES;
    }
    RtlZeroMemory(pspi, ReturnLength);    

    status = ZwQuerySystemInformation(SystemProcessInformation, pspi, SystemInformationLength, &ReturnLength);
    if( !NT_SUCCESS( status ) )
    {
        KdPrint(("ZwQuerySystemInformation fail with 0x%x in line %d\n",status, __LINE__));
        ExFreePoolWithTag( pspi, TAG );
        return status;
    }

    //枚举进程信息。
    //判定系统进程的好的办法是和PEPROCESS PsInitialSystemProcess比较。
    for (pspi_temp = pspi ; /* pspi_temp->NextEntryOffset != 0 */; /*pspi_temp++*/) //注释的都是有问题的，如少显示一个等，可以改为while。
    {
        //KdPrint(("PID:%d\tNumberOfThreads:%d\tHandleCount:%d\n",pspi_temp->UniqueProcessId, pspi_temp->NumberOfThreads, pspi_temp->HandleCount));

        if (UniqueProcessId == pspi_temp->UniqueProcessId)
        { 
            //枚举线程信息。
            for (i = 0, psti = pspi_temp->TH; i < pspi_temp->NumberOfThreads; i++)
            {
                /*
                注意：
                1.有同一个地址跑多个线程的情况。特别是在系统进程。
                2.X64系统上有的线程地址为0等.感觉这个不重要，重要的是获取了TID。
                */            
                KdPrint(("    TID:%d属于PID:%d，StartAddress:%p\n", psti->ClientId.UniqueThread, psti->ClientId.UniqueProcess, psti->StartAddress));

                KdPrint(("    ThreadState:%d\n", psti->ThreadState));

                if (5 == psti->ThreadState) // && (g_b == 1)  只注入一次。  经观察：5就是线程的等待状态，具体的定义没有找到。
                {
                    QueueApcThread(&psti->ClientId);//注意，这里插入了，何时运行还未知：快的需要几秒，慢的需要及分钟，甚至几十分钟，更深的几个小时或者几天几夜，甚至永远不会运行，如：不触发或者线程的状态不符合。
                    g_b++;
                }

                /*
                并且断言：psti <= ((char *)pspi_temp + pspi_temp->NextEntryOffset)
                */
                psti = (PSYSTEM_THREAD_INFORMATION)((char *)psti + sizeof(SYSTEM_THREAD_INFORMATION));
            }
        }

        /*
        The start of the next item in the array is the address of the previous item plus the value in the NextEntryOffset member. 
        For the last item in the array, NextEntryOffset is 0.
        摘自：http://msdn.microsoft.com/en-us/library/windows/desktop/ms724509(v=vs.85).aspx。
        说明：NextEntryOffset的值是不固定的，更不是SYSTEM_PROCESS_INFORMATION结构的大小。所以不能加一个结构的大小来遍历。
        */

        if (pspi_temp->NextEntryOffset == 0)
        {
            break;
        }

        pspi_temp = (SYSTEM_PROCESS_INFORMATION *)((char *)pspi_temp + pspi_temp->NextEntryOffset);
    }

    ExFreePoolWithTag( pspi, TAG );

    return status;//STATUS_SUCCESS
} 


NTSTATUS stop()
{
    NTSTATUS status = STATUS_SUCCESS;


    return status;
}


PVOID MiFindExportedRoutineByName (IN PVOID DllBase, IN PANSI_STRING AnsiImageRoutineName)
/*++
Routine Description:
    This function searches the argument module looking for the requested exported function name.
Arguments:
    DllBase - Supplies the base address of the requested module.
    AnsiImageRoutineName - Supplies the ANSI routine name being searched for.
Return Value:
    The virtual address of the requested routine or NULL if not found.
--*/
{
    USHORT OrdinalNumber;
    PULONG NameTableBase;
    PUSHORT NameOrdinalTableBase;
    PULONG Addr;
    LONG High;
    LONG Low;
    LONG Middle;
    LONG Result;
    ULONG ExportSize;
    PVOID FunctionAddress = 0;
    PIMAGE_EXPORT_DIRECTORY ExportDirectory;

    PAGED_CODE();

    __try
    {
        FunctionAddress = *(PVOID *)DllBase;
        FunctionAddress = 0;
    }
    __except(EXCEPTION_EXECUTE_HANDLER)
    {
        return FunctionAddress;
    }  

    //确保DllBase可以访问。否则蓝屏。
    ExportDirectory = (PIMAGE_EXPORT_DIRECTORY) RtlImageDirectoryEntryToData (DllBase, TRUE, IMAGE_DIRECTORY_ENTRY_EXPORT, &ExportSize);
    if (ExportDirectory == NULL) {
        return NULL;
    }
    
    NameTableBase = (PULONG)((PCHAR)DllBase + (ULONG)ExportDirectory->AddressOfNames);// Initialize the pointer to the array of RVA-based ansi export strings.    
    NameOrdinalTableBase = (PUSHORT)((PCHAR)DllBase + (ULONG)ExportDirectory->AddressOfNameOrdinals);// Initialize the pointer to the array of USHORT ordinal numbers.    
    Low = 0;
    Middle = 0;
    High = ExportDirectory->NumberOfNames - 1;

    while (High >= Low) // Lookup the desired name in the name table using a binary search.
    {        
        Middle = (Low + High) >> 1;// Compute the next probe index and compare the import name with the export name entry.
        Result = strcmp (AnsiImageRoutineName->Buffer, (PCHAR)DllBase + NameTableBase[Middle]);
        if (Result < 0) {
            High = Middle - 1;
        } else if (Result > 0) {
            Low = Middle + 1;
        } else {
            break;
        }
    }

    // If the high index is less than the low index, then a matching table entry was not found.
    // Otherwise, get the ordinal number from the ordinal table.
    if (High < Low) {
        return NULL;
    }

    OrdinalNumber = NameOrdinalTableBase[Middle];

    // If the OrdinalNumber is not within the Export Address Table,then this image does not implement the function.
    // Return not found.
    if ((ULONG)OrdinalNumber >= ExportDirectory->NumberOfFunctions) {
        return NULL;
    }

    // Index into the array of RVA export addresses by ordinal number.
    Addr = (PULONG)((PCHAR)DllBase + (ULONG)ExportDirectory->AddressOfFunctions);
    FunctionAddress = (PVOID)((PCHAR)DllBase + Addr[OrdinalNumber]);

    // Forwarders are not used by the kernel and HAL to each other.
    ASSERT ((FunctionAddress <= (PVOID)ExportDirectory) || (FunctionAddress >= (PVOID)((PCHAR)ExportDirectory + ExportSize)));

    return FunctionAddress;
}


BOOL GetUserAPIAddress (IN HANDLE ProcessId)
    /*
    不支持IDLE和SYStem进程。
    */
{
    PEPROCESS    m_process;
    NTSTATUS     status = STATUS_SUCCESS;
    KAPC_STATE   m_kapc_state;
    PPEB         ppeb;
    PLDR_DATA_TABLE_ENTRY pldte;
    PLIST_ENTRY le1,le2;
    UNICODE_STRING user32 = RTL_CONSTANT_STRING(L"user32.dll");
    PUNICODE_STRING pus = NULL;

    if (ProcessId == 0)
    {
        return FALSE ;
    }

    if (PsGetProcessId(PsInitialSystemProcess) == ProcessId)
    {
        return FALSE ;
    }

    status=PsLookupProcessByProcessId(ProcessId,&m_process);//得到指定进程ID的进程环境块
    if(!NT_SUCCESS(status)) {
        return FALSE ;
    }

    KeStackAttachProcess (m_process,&m_kapc_state); //附加当前线程到目标进程空间内    

    ppeb = PsGetProcessPeb(m_process);//注意：IDLE和system这两个应该获取不到。
    le1 = ppeb->Ldr->InMemoryOrderModuleList.Flink;
    le2 = le1 ;
    do 
    {
        pldte = (PLDR_DATA_TABLE_ENTRY)CONTAINING_RECORD(le1, LDR_DATA_TABLE_ENTRY, InMemoryOrderLinks);
        if (pldte->FullDllName.Length) //过滤掉最后一个，多余的。
        {
            //KdPrint(("FullDllName:%wZ \n", &pldte->FullDllName));//"C:\WINDOWS\system32\USER32.dll"，因为这里是完整路径，另一个思路是获取系统路径再组合。

            pus = (PUNICODE_STRING)&pldte->Reserved4;
            //if (RtlCompareUnicodeString(&pldte->FullDllName, &user32, TRUE) == 0)
            if (RtlCompareUnicodeString(pus, &user32, TRUE) == 0)
            {
                ANSI_STRING test  = RTL_CONSTANT_STRING("MessageBoxW");

                g_MessageBox = (MessageBoxT)MiFindExportedRoutineByName (pldte->DllBase, &test);
                ASSERT(g_MessageBox);
                break;
            }
        }
        le1 = le1->Flink;
    }while (le1 != le2);

    KeUnstackDetachProcess(&m_kapc_state);//解除附加

    ObDereferenceObject(m_process);

    return TRUE ;
}


VOID GetApcStateOffset()
    /*
    代码和思路：http://www.rohitab.com/discuss/topic/40737-inject-dll-from-kernel-mode/
    */
{
    PEPROCESS Process = PsGetCurrentProcess();
    PETHREAD Thread = PsGetCurrentThread();
    PKAPC_STATE ApcState = NULL;
    SIZE_T * p = (SIZE_T *)Thread;
    int i = 0;

    // Locate the ApcState structure
    for(; i < 512; i++)
    {
        if( p[i] == (SIZE_T)Process)
        {
            ApcState = CONTAINING_RECORD(&p[i], KAPC_STATE, Process); // Get the actual address of KAPC_STATE
            ApcStateOffset = (SIZE_T)ApcState - (SIZE_T)Thread; // Calculate the offset of the ApcState structure
            break;
        }
    }
}


NTSTATUS start()
{
    NTSTATUS status = STATUS_SUCCESS;
    HANDLE UniqueProcessId = 0;    

    GetApcStateOffset();

    status = GetPidFromProcessName (L"explorer.exe", &UniqueProcessId);//explorer.exe notepad.exe
    if (!NT_SUCCESS(status)) {
        return status;
    }
    ASSERT(UniqueProcessId);

    GetUserAPIAddress(UniqueProcessId);    

    return ProcessAllThread(UniqueProcessId);
}


DRIVER_UNLOAD Unload;
VOID Unload(__in PDRIVER_OBJECT DriverObject)
{
    stop();
}


DRIVER_INITIALIZE DriverEntry;
NTSTATUS DriverEntry( __in struct _DRIVER_OBJECT  * DriverObject, __in PUNICODE_STRING  RegistryPath)
{
    KdBreakPoint();

    DriverObject->DriverUnload = Unload;     

    return start();
}